# 🚀 Guia Completo: Como Publicar no Domínio tera.com via Cloudflare

## ✨ Cores Ajustadas - Concluído!
✅ **Gradientes Principais**: Azul (#0369a1) + Verde (#059669)
✅ **Accent Sutil**: Roxo (#7c3aed) apenas em badges e detalhes
✅ **Harmonia Visual**: Azul predominante → Verde secundário → Roxo como destaque

---

## 📋 Pré-requisitos

### 1. **Conta Cloudflare**
- Acesse [cloudflare.com](https://cloudflare.com)
- Crie uma conta gratuita se ainda não tiver

### 2. **Domínio tera.com**
- Certifique-se que você é o proprietário do domínio
- Tenha acesso ao painel de controle do registrador

### 3. **Código Pronto**
- ✅ Site já está otimizado e funcionando
- ✅ Build gerado em `/dist`
- ✅ Configuração Cloudflare Pages ready

---

## 🔧 Processo de Publicação

### **PASSO 1: Configurar DNS no Cloudflare**

1. **Adicionar Site ao Cloudflare:**
   ```
   Cloudflare Dashboard → Add a Site → Digite: tera.com
   ```

2. **Alterar Name Servers:**
   - Cloudflare fornecerá 2 nameservers (ex: `ns1.cloudflare.com`)
   - No seu registrador de domínio, altere os nameservers para os fornecidos
   - ⏱️ Aguarde propagação (até 24h, geralmente 2-4h)

### **PASSO 2: Configurar Cloudflare Pages**

1. **Criar Projeto Pages:**
   ```
   Cloudflare Dashboard → Pages → Create a project → Upload assets
   ```

2. **Upload do Build:**
   ```bash
   # No seu computador, comprima a pasta dist/
   zip -r dist.zip dist/
   
   # Faça upload do arquivo zip no Cloudflare Pages
   ```

3. **Configurar Domínio Personalizado:**
   ```
   Pages Project → Custom domains → Add custom domain → tera.com
   ```

---

## 🔐 Configuração Avançada (Recomendado)

### **SSL/TLS (Automático)**
- Cloudflare gera certificado SSL automaticamente
- Site será acessível via https://tera.com

### **Otimizações de Performance**
```
Cloudflare Dashboard → Speed → Optimization:
✅ Auto Minify (CSS, JS, HTML)
✅ Brotli compression
✅ Rocket Loader™
✅ Polish (Image optimization)
```

### **Configurações de Cache**
```
Caching → Configuration:
- Browser Cache TTL: 4 hours
- Caching Level: Standard
```

---

## 📁 Estrutura de Deploy

### **Arquivos que vão para produção:**
```
dist/
├── _worker.js          # Aplicação Hono compilada
├── _routes.json        # Configuração de rotas
├── index.html          # Fallback (se necessário)
└── static/             # Assets estáticos (se houver)
```

### **Configuração Automática:**
```json
// wrangler.jsonc (já configurado)
{
  "name": "webapp",
  "compatibility_date": "2024-01-01", 
  "pages_build_output_dir": "./dist"
}
```

---

## 🚀 Deploy Alternativo via GitHub (Recomendado)

### **Opção Mais Profissional:**

1. **Push para GitHub:**
   ```bash
   git remote add origin https://github.com/seu-usuario/tera-website.git
   git push -u origin main
   ```

2. **Conectar GitHub ao Cloudflare Pages:**
   ```
   Pages → Create project → Connect to Git → Select repository
   
   Build settings:
   - Framework preset: Hono
   - Build command: npm run build
   - Build output directory: dist
   ```

3. **Deploy Automático:**
   - Cada push na branch `main` = deploy automático
   - Preview de branches para testar mudanças

---

## ⚡ Configurações Específicas para tera.com

### **DNS Records (após adicionar site):**
```
Type: A     Name: tera.com        Value: 192.0.2.1 (Cloudflare Proxy)
Type: CNAME Name: www             Value: tera.com
Type: CNAME Name: *               Value: tera.com (opcional, wildcard)
```

### **Page Rules (Otimizações):**
```
URL Pattern: tera.com/*
Settings:
- Always Use HTTPS: On
- Browser Cache TTL: 4 hours
- Cache Level: Cache Everything
```

---

## ✅ Checklist Final

### **Antes do Deploy:**
- [ ] Build está funcionando: `npm run build`
- [ ] Teste local OK: site carrega em `localhost:3000`
- [ ] Links WhatsApp funcionando
- [ ] Links de pagamento Asaas funcionando
- [ ] Responsive design OK

### **Após Deploy:**
- [ ] https://tera.com carrega corretamente
- [ ] SSL ativo (cadeado verde)
- [ ] Todas as páginas/links funcionando
- [ ] Formulário de contato enviando
- [ ] WhatsApp redirecionando corretamente
- [ ] Pagamentos Asaas funcionando

---

## 🆘 Solução de Problemas

### **Site não carrega:**
```bash
# Verificar DNS
dig tera.com

# Verificar SSL
curl -I https://tera.com
```

### **Erro 522 (Connection Timeout):**
- Aguardar propagação DNS (até 24h)
- Verificar se nameservers foram alterados corretamente

### **Erro 404:**
- Verificar se o upload da pasta `dist` foi completo
- Confirmar que `_worker.js` existe no projeto

---

## 📞 Suporte

### **Documentação Oficial:**
- [Cloudflare Pages Docs](https://developers.cloudflare.com/pages/)
- [Hono Cloudflare Guide](https://hono.dev/getting-started/cloudflare-pages)

### **Comunidade:**
- Cloudflare Community Forum
- Hono Discord Server

---

**🎉 Resultado Final:** Seu site estará online em https://tera.com com performance otimizada, SSL automático e CDN global!

**⚡ Performance:** Load time < 1s globalmente
**🔒 Segurança:** SSL/TLS automático
**🌍 Disponibilidade:** 99.9% uptime
**📈 Escalabilidade:** Suporte para milhões de visitas/mês