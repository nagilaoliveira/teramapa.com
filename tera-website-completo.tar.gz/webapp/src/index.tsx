import { Hono } from 'hono'
import { cors } from 'hono/cors'
import { serveStatic } from 'hono/cloudflare-workers'

const app = new Hono()

// Enable CORS for API routes
app.use('/api/*', cors())

// Serve static files
app.use('/static/*', serveStatic({ root: './public' }))

// API route para contato/leads
app.post('/api/contact', async (c) => {
  try {
    const { name, email, phone, service } = await c.req.json()
    
    // Aqui você pode integrar com um serviço de email ou CRM
    console.log('Novo lead:', { name, email, phone, service })
    
    return c.json({ 
      success: true, 
      message: 'Mensagem enviada com sucesso!' 
    })
  } catch (error) {
    return c.json({ 
      success: false, 
      message: 'Erro ao enviar mensagem' 
    }, 400)
  }
})

// Página principal
app.get('/', (c) => {
  return c.html(`
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Perfil de Empresa | SEO Local | Marketing Digital em Fortaleza</title>
        <meta name="description" content="Especialistas em Google Perfil da Empresa. Recuperação, criação, SEO Local e gerenciamento completo. Transforme sua presença digital!">
        
        <script src="https://cdn.tailwindcss.com"></script>
        <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
        
        <script>
          tailwind.config = {
            theme: {
              extend: {
                colors: {
                  'navy-blue': '#0f172a',
                  'deep-blue': '#1e293b',
                  'ocean-blue': '#0369a1',
                  'emerald': '#059669',
                  'forest-green': '#047857',
                  'purple-accent': '#7c3aed',
                  'accent-green': '#10b981',
                  'accent-blue': '#0ea5e9'
                },
                animation: {
                  'float': 'float 6s ease-in-out infinite',
                  'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
                }
              }
            }
          }
        </script>
        
        <style>
          @keyframes float {
            0%, 100% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
          }
          
          .gradient-text {
            background: linear-gradient(135deg, #0ea5e9, #10b981, #7c3aed);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
          }
          
          .glass-card {
            background: rgba(15, 23, 42, 0.4);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(16, 185, 129, 0.25);
          }
          
          .hero-gradient {
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 20%, #0369a1 40%, #059669 70%, #047857 90%, #7c3aed 100%);
          }
          
          .service-card:hover {
            transform: translateY(-10px);
            transition: all 0.3s ease;
            box-shadow: 0 20px 40px rgba(16, 185, 129, 0.3);
          }
          
          .whatsapp-float {
            position: fixed;
            bottom: 20px;
            right: 20px;
            z-index: 1000;
            animation: float 3s ease-in-out infinite;
            box-shadow: 0 10px 30px rgba(34, 197, 94, 0.4);
          }
          
          .dark-section {
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 30%, #0369a1 60%, #047857 100%);
          }
          
          .blue-green-gradient {
            background: linear-gradient(135deg, #0369a1 0%, #0ea5e9 30%, #10b981 70%, #059669 100%);
          }
          
          .green-blue-gradient {
            background: linear-gradient(135deg, #047857 0%, #059669 30%, #10b981 70%, #0ea5e9 100%);
          }
        </style>
    </head>
    <body class="bg-slate-900 overflow-x-hidden">
        <!-- Header -->
        <header class="bg-slate-900/95 backdrop-blur-sm shadow-2xl fixed w-full top-0 z-50 border-b border-emerald-500/20">
            <nav class="container mx-auto px-6 py-4">
                <div class="flex justify-between items-center">
                    <div class="flex items-center space-x-2">
                        <i class="fas fa-map-marker-alt text-2xl bg-gradient-to-r from-emerald-400 to-green-500 bg-clip-text text-transparent"></i>
                        <span class="text-xl font-bold gradient-text">Perfil de Empresa Fortaleza</span>
                    </div>
                    
                    <div class="hidden md:flex items-center space-x-8">
                        <a href="#services" class="text-gray-300 hover:text-emerald-400 transition">Serviços</a>
                        <a href="#plans" class="text-gray-300 hover:text-emerald-400 transition">Planos</a>
                        <a href="#about" class="text-gray-300 hover:text-emerald-400 transition">Sobre</a>
                        <a href="#contact" class="bg-gradient-to-r from-emerald-600 to-purple-600 text-white px-6 py-2 rounded-full hover:shadow-lg transition">Contato</a>
                    </div>
                    
                    <div class="md:hidden">
                        <button id="mobile-menu-btn" class="text-gray-300">
                            <i class="fas fa-bars text-xl"></i>
                        </button>
                    </div>
                </div>
                
                <!-- Mobile Menu -->
                <div id="mobile-menu" class="hidden md:hidden mt-4 pb-4">
                    <a href="#services" class="block py-2 text-gray-300 hover:text-emerald-400">Serviços</a>
                    <a href="#plans" class="block py-2 text-gray-300 hover:text-emerald-400">Planos</a>
                    <a href="#about" class="block py-2 text-gray-300 hover:text-emerald-400">Sobre</a>
                    <a href="#contact" class="block py-2 text-gray-300 hover:text-emerald-400">Contato</a>
                </div>
            </nav>
        </header>

        <!-- Hero Section -->
        <section class="hero-gradient min-h-screen flex items-center justify-center relative overflow-hidden pt-20">
            <!-- Background Elements -->
            <div class="absolute inset-0 opacity-10">
                <div class="absolute top-1/4 left-1/4 w-64 h-64 bg-white rounded-full animate-pulse-slow"></div>
                <div class="absolute bottom-1/4 right-1/4 w-48 h-48 bg-white rounded-full animate-float"></div>
                <div class="absolute top-1/2 right-1/3 w-32 h-32 bg-white rounded-full animate-pulse-slow"></div>
            </div>
            
            <div class="container mx-auto px-6 text-center relative z-10">
                <div class="max-w-4xl mx-auto">
                    <h1 class="text-5xl md:text-7xl font-bold text-white mb-6 animate-fade-in leading-tight">
                        <span class="text-white">Domine o </span>
                        <br class="md:hidden">
                        <span class="gradient-text bg-gradient-to-r from-cyan-400 via-emerald-400 to-blue-400 bg-clip-text text-transparent">
                            Google Perfil
                        </span>
                        <br> 
                        <span class="text-slate-200">da sua Empresa</span>
                    </h1>
                    
                    <p class="text-xl md:text-2xl text-slate-200 mb-8 leading-relaxed">
                        Especialistas em recuperação, criação e otimização de perfis do Google. 
                        <strong class="text-emerald-400">Aumente sua visibilidade local em até 300%</strong>
                    </p>
                    
                    <div class="flex flex-col md:flex-row gap-4 justify-center items-center mb-12">
                        <a href="#plans" class="relative bg-gradient-to-r from-emerald-500 via-green-500 to-teal-500 text-white px-10 py-5 rounded-full text-xl font-bold hover:shadow-2xl transform hover:scale-110 transition-all duration-300 shadow-2xl shadow-emerald-500/50 border-2 border-emerald-300/50 animate-pulse">
                            <i class="fas fa-rocket mr-3 text-lg"></i>
                            Ver Planos
                            <div class="absolute -top-2 -right-2 bg-gradient-to-r from-yellow-400 to-orange-500 text-black text-xs font-bold px-3 py-1 rounded-full animate-bounce">
                                OFERTA
                            </div>
                        </a>
                        <a href="https://wa.me/5585996720379?text=Ola! Gostaria de saber mais sobre os servicos de Google Perfil da Empresa." 
                           class="glass-card text-white px-8 py-4 rounded-full text-lg font-semibold hover:bg-emerald-500/20 transition-all duration-300" target="_blank">
                            <i class="fab fa-whatsapp mr-2"></i>
                            Conversar Agora
                        </a>
                    </div>
                    
                    <!-- Stats -->
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
                        <div class="glass-card p-6 rounded-xl text-center">
                            <div class="text-4xl font-bold text-blue-400 mb-2">500+</div>
                            <div class="text-slate-200">Perfis Recuperados</div>
                        </div>
                        <div class="glass-card p-6 rounded-xl text-center">
                            <div class="text-4xl font-bold text-green-400 mb-2">300%</div>
                            <div class="text-slate-200">Aumento Médio de Visibilidade</div>
                        </div>
                        <div class="glass-card p-6 rounded-xl text-center">
                            <div class="text-4xl font-bold text-blue-400 mb-2">98%</div>
                            <div class="text-slate-200">Taxa de Sucesso</div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Services Section -->
        <section id="services" class="py-20 dark-section">
            <div class="container mx-auto px-6">
                <div class="text-center mb-16">
                    <h2 class="text-4xl md:text-5xl font-bold gradient-text mb-6">
                        Nossos Serviços Especializados
                    </h2>
                    <p class="text-xl text-slate-300 max-w-3xl mx-auto">
                        Soluções completas para transformar sua presença no Google e dominar as buscas locais
                    </p>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <!-- Recuperação de Perfil -->
                    <div class="service-card bg-gradient-to-br from-slate-800 to-blue-900/50 p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 border border-blue-500/20">
                        <div class="bg-gradient-to-r from-blue-600 to-blue-700 w-16 h-16 rounded-2xl flex items-center justify-center mb-6">
                            <i class="fas fa-undo-alt text-2xl text-white"></i>
                        </div>
                        <h3 class="text-2xl font-bold text-white mb-4">Recuperação de Perfil</h3>
                        <p class="text-slate-300 mb-6">Perfil suspenso ou bloqueado? Recuperamos seu Google Perfil da Empresa com nossa metodologia comprovada.</p>
                        <ul class="space-y-2 text-sm text-slate-400">
                            <li><i class="fas fa-check text-blue-400 mr-2"></i>Análise completa do caso</li>
                            <li><i class="fas fa-check text-blue-400 mr-2"></i>Documentação especializada</li>
                            <li><i class="fas fa-check text-blue-400 mr-2"></i>Acompanhamento até resolução</li>
                        </ul>
                    </div>

                    <!-- Criação de Perfil -->
                    <div class="service-card bg-gradient-to-br from-slate-800 to-emerald-900/50 p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 border border-emerald-500/20">
                        <div class="bg-gradient-to-r from-emerald-600 to-emerald-700 w-16 h-16 rounded-2xl flex items-center justify-center mb-6">
                            <i class="fas fa-plus-circle text-2xl text-white"></i>
                        </div>
                        <h3 class="text-2xl font-bold text-white mb-4">Criação de Perfil</h3>
                        <p class="text-slate-300 mb-6">Criamos seu Google Perfil da Empresa do zero, otimizado para máxima visibilidade desde o primeiro dia.</p>
                        <ul class="space-y-2 text-sm text-slate-400">
                            <li><i class="fas fa-check text-emerald-400 mr-2"></i>Setup completo e otimizado</li>
                            <li><i class="fas fa-check text-emerald-400 mr-2"></i>Verificação garantida</li>
                            <li><i class="fas fa-check text-emerald-400 mr-2"></i>Configurações avançadas</li>
                        </ul>
                    </div>

                    <!-- SEO Local -->
                    <div class="service-card bg-gradient-to-br from-slate-800 to-blue-900/50 p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 border border-blue-500/20">
                        <div class="bg-gradient-to-r from-blue-600 to-cyan-700 w-16 h-16 rounded-2xl flex items-center justify-center mb-6">
                            <i class="fas fa-search-location text-2xl text-white"></i>
                        </div>
                        <h3 class="text-2xl font-bold text-white mb-4">SEO Local</h3>
                        <p class="text-slate-300 mb-6">Otimização completa para aparecer nas primeiras posições nas buscas locais do Google.</p>
                        <ul class="space-y-2 text-sm text-slate-400">
                            <li><i class="fas fa-check text-blue-400 mr-2"></i>Otimização de palavras-chave</li>
                            <li><i class="fas fa-check text-blue-400 mr-2"></i>Gestão de avaliações</li>
                            <li><i class="fas fa-check text-blue-400 mr-2"></i>Relatórios mensais</li>
                        </ul>
                    </div>

                    <!-- Posicionamento -->
                    <div class="service-card bg-gradient-to-br from-slate-800 to-emerald-900/50 p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 border border-emerald-500/20">
                        <div class="bg-gradient-to-r from-emerald-600 to-teal-700 w-16 h-16 rounded-2xl flex items-center justify-center mb-6">
                            <i class="fas fa-chart-line text-2xl text-white"></i>
                        </div>
                        <h3 class="text-2xl font-bold text-white mb-4">Posicionamento</h3>
                        <p class="text-slate-300 mb-6">Estratégias avançadas para posicionar seu negócio no topo dos resultados locais.</p>
                        <ul class="space-y-2 text-sm text-slate-400">
                            <li><i class="fas fa-check text-emerald-400 mr-2"></i>Análise da concorrência</li>
                            <li><i class="fas fa-check text-emerald-400 mr-2"></i>Estratégias personalizadas</li>
                            <li><i class="fas fa-check text-emerald-400 mr-2"></i>Monitoramento contínuo</li>
                        </ul>
                    </div>

                    <!-- Gerenciamento -->
                    <div class="service-card bg-gradient-to-br from-slate-800 to-blue-900/50 p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 border border-blue-500/20">
                        <div class="bg-gradient-to-r from-blue-600 to-indigo-700 w-16 h-16 rounded-2xl flex items-center justify-center mb-6">
                            <i class="fas fa-cogs text-2xl text-white"></i>
                        </div>
                        <h3 class="text-2xl font-bold text-white mb-4">Gerenciamento</h3>
                        <p class="text-slate-300 mb-6">Gerenciamento completo e contínuo do seu Google Perfil da Empresa.</p>
                        <ul class="space-y-2 text-sm text-slate-400">
                            <li><i class="fas fa-check text-blue-400 mr-2"></i>Postagens regulares</li>
                            <li><i class="fas fa-check text-blue-400 mr-2"></i>Resposta a avaliações</li>
                            <li><i class="fas fa-check text-blue-400 mr-2"></i>Atualizações de informações</li>
                        </ul>
                    </div>

                    <!-- Consultoria -->
                    <div class="service-card bg-gradient-to-br from-slate-800 to-emerald-900/50 p-8 rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 border border-emerald-500/20">
                        <div class="bg-gradient-to-r from-emerald-600 to-green-700 w-16 h-16 rounded-2xl flex items-center justify-center mb-6">
                            <i class="fas fa-user-tie text-2xl text-white"></i>
                        </div>
                        <h3 class="text-2xl font-bold text-white mb-4">Consultoria Especializada</h3>
                        <p class="text-slate-300 mb-6">Consultoria estratégica para maximizar o potencial do seu negócio local.</p>
                        <ul class="space-y-2 text-sm text-slate-400">
                            <li><i class="fas fa-check text-emerald-400 mr-2"></i>Diagnóstico completo</li>
                            <li><i class="fas fa-check text-emerald-400 mr-2"></i>Estratégia personalizada</li>
                            <li><i class="fas fa-check text-emerald-400 mr-2"></i>Suporte especializado</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <!-- Plans Section -->
        <section id="plans" class="py-20 bg-gradient-to-br from-slate-800 to-slate-900">
            <div class="container mx-auto px-6">
                <div class="text-center mb-16">
                    <h2 class="text-4xl md:text-5xl font-bold gradient-text mb-6">
                        Planos com Fidelidade
                    </h2>
                    <p class="text-xl text-slate-300 max-w-3xl mx-auto">
                        Investimento inteligente com resultados garantidos. Escolha o plano ideal para seu negócio.
                    </p>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
                    <!-- Plano Anual -->
                    <div class="bg-gradient-to-br from-slate-700 to-slate-800 rounded-3xl shadow-2xl overflow-hidden transform hover:scale-105 transition-all duration-300 relative border border-blue-500/30">
                        <div class="bg-gradient-to-r from-blue-600 to-emerald-600 px-8 py-6 relative">
                            <div class="absolute top-4 right-4">
                                <div class="bg-purple-400 text-slate-900 px-3 py-1 rounded-full text-sm font-bold">
                                    MAIS POPULAR
                                </div>
                            </div>
                            <h3 class="text-2xl font-bold text-white mb-2">Plano Anual</h3>
                            <div class="text-blue-100 text-lg">Fidelidade de 12 meses</div>
                            <div class="mt-4">
                                <span class="text-5xl font-bold text-white">R$ 499</span>
                                <span class="text-blue-100 text-lg">/mês</span>
                            </div>
                            <div class="text-blue-200 text-sm mt-2">
                                Economia de R$ 2.400 por ano
                            </div>
                        </div>
                        
                        <div class="p-8">
                            <ul class="space-y-4 mb-8">
                                <li class="flex items-center">
                                    <i class="fas fa-check-circle text-blue-400 mr-3"></i>
                                    <span class="text-slate-200">Todos os serviços inclusos</span>
                                </li>
                                <li class="flex items-center">
                                    <i class="fas fa-check-circle text-blue-400 mr-3"></i>
                                    <span class="text-slate-200">Suporte prioritário 24/7</span>
                                </li>
                                <li class="flex items-center">
                                    <i class="fas fa-check-circle text-blue-400 mr-3"></i>
                                    <span class="text-slate-200">Relatórios mensais detalhados</span>
                                </li>
                                <li class="flex items-center">
                                    <i class="fas fa-check-circle text-blue-400 mr-3"></i>
                                    <span class="text-slate-200">Consultoria estratégica mensal</span>
                                </li>
                                <li class="flex items-center">
                                    <i class="fas fa-check-circle text-blue-400 mr-3"></i>
                                    <span class="text-slate-200">Garantia de resultados</span>
                                </li>
                                <li class="flex items-center">
                                    <i class="fas fa-crown text-purple-400 mr-3"></i>
                                    <span class="font-semibold text-purple-400">2 meses GRÁTIS</span>
                                </li>
                            </ul>
                            
                            <button onclick="openPaymentModal('anual')" class="w-full bg-gradient-to-r from-blue-600 to-emerald-600 text-white py-4 rounded-xl font-semibold text-lg hover:shadow-lg transition-all duration-300">
                                <i class="fas fa-credit-card mr-2"></i>
                                Assinar Agora
                            </button>
                        </div>
                    </div>

                    <!-- Plano Semestral -->
                    <div class="bg-gradient-to-br from-slate-700 to-slate-800 rounded-3xl shadow-xl overflow-hidden transform hover:scale-105 transition-all duration-300 border border-green-500/30">
                        <div class="bg-gradient-to-r from-green-600 to-emerald-600 px-8 py-6">
                            <h3 class="text-2xl font-bold text-white mb-2">Plano Semestral</h3>
                            <div class="text-green-100 text-lg">Fidelidade de 6 meses</div>
                            <div class="mt-4">
                                <span class="text-5xl font-bold text-white">R$ 699</span>
                                <span class="text-green-100 text-lg">/mês</span>
                            </div>
                            <div class="text-green-200 text-sm mt-2">
                                Flexibilidade com ótimo custo-benefício
                            </div>
                        </div>
                        
                        <div class="p-8">
                            <ul class="space-y-4 mb-8">
                                <li class="flex items-center">
                                    <i class="fas fa-check-circle text-green-400 mr-3"></i>
                                    <span class="text-slate-200">Todos os serviços inclusos</span>
                                </li>
                                <li class="flex items-center">
                                    <i class="fas fa-check-circle text-green-400 mr-3"></i>
                                    <span class="text-slate-200">Suporte especializado</span>
                                </li>
                                <li class="flex items-center">
                                    <i class="fas fa-check-circle text-green-400 mr-3"></i>
                                    <span class="text-slate-200">Relatórios mensais</span>
                                </li>
                                <li class="flex items-center">
                                    <i class="fas fa-check-circle text-green-400 mr-3"></i>
                                    <span class="text-slate-200">Consultoria bimestral</span>
                                </li>
                                <li class="flex items-center">
                                    <i class="fas fa-check-circle text-green-400 mr-3"></i>
                                    <span class="text-slate-200">Acompanhamento de resultados</span>
                                </li>
                                <li class="flex items-center">
                                    <i class="fas fa-star text-green-400 mr-3"></i>
                                    <span class="text-slate-200">Setup prioritário</span>
                                </li>
                            </ul>
                            
                            <button onclick="openPaymentModal('semestral')" class="w-full bg-gradient-to-r from-green-600 to-emerald-600 text-white py-4 rounded-xl font-semibold text-lg hover:shadow-lg transition-all duration-300">
                                <i class="fas fa-credit-card mr-2"></i>
                                Assinar Agora
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- About Section -->
        <section id="about" class="py-20 dark-section">
            <div class="container mx-auto px-6">
                <div class="max-w-4xl mx-auto text-center">
                    <h2 class="text-4xl md:text-5xl font-bold gradient-text mb-8">
                        Por Que Escolher Nossa Expertise?
                    </h2>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-12 items-center mt-16">
                        <div class="space-y-6">
                            <div class="flex items-start space-x-4">
                                <div class="bg-gradient-to-br from-slate-600 via-slate-700 to-slate-800 p-4 rounded-2xl border-2 border-emerald-500/30 shadow-lg shadow-emerald-500/20">
                                    <i class="fas fa-medal text-emerald-400 text-2xl"></i>
                                </div>
                                <div>
                                    <h3 class="text-xl font-semibold mb-2 text-white">Especialização Exclusiva</h3>
                                    <p class="text-slate-300">Focamos 100% em Google Perfil da Empresa com metodologia especializada.</p>
                                </div>
                            </div>
                            
                            <div class="flex items-start space-x-4">
                                <div class="bg-gradient-to-br from-slate-600 via-slate-700 to-slate-800 p-4 rounded-2xl border-2 border-purple-500/30 shadow-lg shadow-purple-500/20">
                                    <i class="fas fa-chart-line text-purple-400 text-2xl"></i>
                                </div>
                                <div>
                                    <h3 class="text-xl font-semibold mb-2 text-white">Resultados Comprovados</h3>
                                    <p class="text-slate-300">98% de taxa de sucesso e mais de 500 perfis recuperados.</p>
                                </div>
                            </div>
                            
                            <div class="flex items-start space-x-4">
                                <div class="bg-gradient-to-br from-slate-600 via-slate-700 to-slate-800 p-4 rounded-2xl border-2 border-blue-500/30 shadow-lg shadow-blue-500/20">
                                    <i class="fas fa-clock text-blue-400 text-2xl"></i>
                                </div>
                                <div>
                                    <h3 class="text-xl font-semibold mb-2 text-white">Agilidade Garantida</h3>
                                    <p class="text-slate-300">Processos otimizados para resultados rápidos e eficientes.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="bg-gradient-to-br from-slate-800/80 to-purple-900/50 p-8 rounded-2xl border border-purple-500/20">
                            <div class="text-6xl text-purple-400 mb-4">
                                <i class="fas fa-users"></i>
                            </div>
                            <h3 class="text-2xl font-bold text-white mb-4">Nossos Clientes</h3>
                            <p class="text-slate-300 mb-6">
                                Mais de 500 empresas em Fortaleza já confiam em nossos serviços 
                                para dominar as buscas locais no Google.
                            </p>
                            <div class="bg-slate-700/50 p-4 rounded-lg border border-emerald-500/20">
                                <div class="text-3xl font-bold text-green-400 mb-1">98%</div>
                                <div class="text-slate-300">Taxa de satisfação</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Reviews Section -->
        <section class="py-20 bg-gradient-to-br from-slate-900 to-slate-800">
            <div class="container mx-auto px-6">
                <div class="text-center mb-16">
                    <h2 class="text-4xl md:text-5xl font-bold gradient-text mb-6">
                        O Que Nossos Clientes Dizem
                    </h2>
                    <p class="text-xl text-slate-300 max-w-3xl mx-auto">
                        Depoimentos reais de empresários que transformaram seus negócios com nossos serviços
                    </p>
                </div>
                
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
                    <!-- Review 1 -->
                    <div class="bg-gradient-to-br from-slate-700 to-slate-800 rounded-2xl shadow-2xl p-8 transform hover:scale-105 transition-all duration-300 border border-emerald-500/20">
                        <div class="flex items-center mb-4">
                            <div class="w-16 h-16 bg-gradient-to-r from-emerald-500 to-purple-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
                                MC
                            </div>
                            <div class="ml-4">
                                <h4 class="font-bold text-white">Maria Clara</h4>
                                <p class="text-slate-400 text-sm">Restaurante Tempero Cearense</p>
                            </div>
                        </div>
                        <div class="flex text-yellow-400 mb-4">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="text-slate-300 italic">
                            "Incrível! Meu restaurante aparece nas primeiras posições quando as pessoas pesquisam por 'restaurante em Fortaleza'. As vendas aumentaram 250% em 3 meses!"
                        </p>
                    </div>

                    <!-- Review 2 -->
                    <div class="bg-gradient-to-br from-slate-700 to-slate-800 rounded-2xl shadow-2xl p-8 transform hover:scale-105 transition-all duration-300 border border-purple-500/20">
                        <div class="flex items-center mb-4">
                            <div class="w-16 h-16 bg-gradient-to-r from-green-500 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
                                JS
                            </div>
                            <div class="ml-4">
                                <h4 class="font-bold text-white">João Silva</h4>
                                <p class="text-slate-400 text-sm">Oficina Mecânica Silva</p>
                            </div>
                        </div>
                        <div class="flex text-yellow-400 mb-4">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="text-slate-300 italic">
                            "Meu perfil estava suspenso há 6 meses. A equipe conseguiu recuperar e otimizar tudo. Agora recebo 50+ ligações por semana!"
                        </p>
                    </div>

                    <!-- Review 3 -->
                    <div class="bg-gradient-to-br from-slate-700 to-slate-800 rounded-2xl shadow-2xl p-8 transform hover:scale-105 transition-all duration-300 border border-purple-500/20">
                        <div class="flex items-center mb-4">
                            <div class="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
                                AS
                            </div>
                            <div class="ml-4">
                                <h4 class="font-bold text-white">Ana Santos</h4>
                                <p class="text-slate-400 text-sm">Clínica Odontológica Sorriso</p>
                            </div>
                        </div>
                        <div class="flex text-yellow-400 mb-4">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="text-slate-300 italic">
                            "Profissionais excepcionais! Criaram meu perfil do zero e agora sou a dentista mais bem avaliada da Aldeota. Recomendo muito!"
                        </p>
                    </div>
                </div>

                <!-- Additional Reviews Row -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto mt-8">
                    <!-- Review 4 -->
                    <div class="bg-gradient-to-br from-slate-700 to-slate-800 rounded-2xl shadow-2xl p-8 transform hover:scale-105 transition-all duration-300 border border-purple-500/20">
                        <div class="flex items-center mb-4">
                            <div class="w-16 h-16 bg-gradient-to-r from-orange-500 to-red-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
                                PR
                            </div>
                            <div class="ml-4">
                                <h4 class="font-bold text-white">Pedro Rocha</h4>
                                <p class="text-slate-400 text-sm">Advocacia Rocha & Associados</p>
                            </div>
                        </div>
                        <div class="flex text-yellow-400 mb-4">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="text-slate-300 italic">
                            "Excelente trabalho de SEO local! Meu escritório aparece em destaque para advogados em Fortaleza. Novos clientes chegam toda semana."
                        </p>
                    </div>

                    <!-- Review 5 -->
                    <div class="bg-gradient-to-br from-slate-700 to-slate-800 rounded-2xl shadow-2xl p-8 transform hover:scale-105 transition-all duration-300 border border-purple-500/20">
                        <div class="flex items-center mb-4">
                            <div class="w-16 h-16 bg-gradient-to-r from-teal-500 to-green-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
                                LM
                            </div>
                            <div class="ml-4">
                                <h4 class="font-bold text-white">Luciana Mendes</h4>
                                <p class="text-slate-400 text-sm">Salão de Beleza Glamour</p>
                            </div>
                        </div>
                        <div class="flex text-yellow-400 mb-4">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <p class="text-slate-300 italic">
                            "Serviço top! Gerenciam meu perfil todos os dias, respondem avaliações e fazem postagens. Minha agenda está sempre cheia!"
                        </p>
                    </div>
                </div>

                <!-- Stats -->
                <div class="text-center mt-16">
                    <div class="bg-gradient-to-br from-slate-700 to-slate-800 rounded-2xl shadow-2xl p-8 max-w-4xl mx-auto border border-emerald-500/20">
                        <h3 class="text-2xl font-bold text-white mb-6">Resultados Comprovados em Fortaleza</h3>
                        <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                            <div class="text-center">
                                <div class="text-4xl font-bold gradient-text mb-2">500+</div>
                                <div class="text-slate-300">Empresas Atendidas</div>
                            </div>
                            <div class="text-center">
                                <div class="text-4xl font-bold gradient-text mb-2">98%</div>
                                <div class="text-slate-300">Taxa de Sucesso</div>
                            </div>
                            <div class="text-center">
                                <div class="text-4xl font-bold gradient-text mb-2">30+</div>
                                <div class="text-slate-300">Cidades Atendidas</div>
                            </div>
                            <div class="text-center">
                                <div class="text-4xl font-bold gradient-text mb-2">24h</div>
                                <div class="text-slate-300">Suporte Rápido</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Contact Section -->
        <section id="contact" class="py-20 bg-gradient-to-br from-slate-900 via-purple-900 to-emerald-900">
            <div class="container mx-auto px-6">
                <div class="max-w-4xl mx-auto text-center text-white">
                    <h2 class="text-4xl md:text-5xl font-bold mb-8">
                        Pronto para Dominar as Buscas Locais?
                    </h2>
                    <p class="text-xl mb-12">
                        Entre em contato agora e receba uma análise gratuita do seu Google Perfil da Empresa
                    </p>
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div class="glass-card p-8 rounded-2xl">
                            <h3 class="text-2xl font-bold mb-6">Fale Conosco</h3>
                            <form id="contact-form" class="space-y-4">
                                <input type="text" name="name" placeholder="Seu nome" required 
                                       class="w-full px-4 py-3 rounded-lg bg-white/20 border border-white/30 placeholder-white/70 text-white focus:outline-none focus:border-white">
                                <input type="email" name="email" placeholder="Seu email" required 
                                       class="w-full px-4 py-3 rounded-lg bg-white/20 border border-white/30 placeholder-white/70 text-white focus:outline-none focus:border-white">
                                <input type="tel" name="phone" placeholder="Seu telefone" 
                                       class="w-full px-4 py-3 rounded-lg bg-white/20 border border-white/30 placeholder-white/70 text-white focus:outline-none focus:border-white">
                                <select name="service" required 
                                        class="w-full px-4 py-3 rounded-lg bg-white/20 border border-white/30 text-white focus:outline-none focus:border-white">
                                    <option value="" class="bg-gray-800 text-white">Selecione o serviço</option>
                                    <option value="recuperacao" class="bg-gray-800 text-white">Recuperação de Perfil</option>
                                    <option value="criacao" class="bg-gray-800 text-white">Criação de Perfil</option>
                                    <option value="seo-local" class="bg-gray-800 text-white">SEO Local</option>
                                    <option value="posicionamento" class="bg-gray-800 text-white">Posicionamento</option>
                                    <option value="gerenciamento" class="bg-gray-800 text-white">Gerenciamento</option>
                                    <option value="consultoria" class="bg-gray-800 text-white">Consultoria</option>
                                </select>
                                <button type="submit" class="w-full bg-gradient-to-r from-yellow-400 to-orange-500 text-black py-3 rounded-lg font-semibold hover:shadow-lg transition-all duration-300">
                                    <i class="fas fa-paper-plane mr-2"></i>
                                    Enviar Mensagem
                                </button>
                            </form>
                        </div>
                        
                        <div class="space-y-8">
                            <div class="text-center">
                                <h3 class="text-2xl font-bold mb-6">Contato Direto</h3>
                                <a href="https://wa.me/5585996720379?text=Ola! Gostaria de saber mais sobre os servicos de Google Perfil da Empresa." 
                                   target="_blank" 
                                   class="inline-flex items-center bg-green-500 hover:bg-green-600 text-white px-8 py-4 rounded-full text-lg font-semibold transition-all duration-300 transform hover:scale-105">
                                    <i class="fab fa-whatsapp text-2xl mr-3"></i>
                                    WhatsApp Direto
                                </a>
                            </div>
                            
                            <div class="bg-white/10 p-6 rounded-xl">
                                <h4 class="font-bold mb-4">Análise Gratuita</h4>
                                <p class="mb-4">Receba uma análise completa e gratuita:</p>
                                <ul class="space-y-2 text-sm">
                                    <li><i class="fas fa-check text-green-400 mr-2"></i>Diagnóstico do seu perfil atual</li>
                                    <li><i class="fas fa-check text-green-400 mr-2"></i>Identificação de problemas</li>
                                    <li><i class="fas fa-check text-green-400 mr-2"></i>Plano de ação personalizado</li>
                                    <li><i class="fas fa-check text-green-400 mr-2"></i>Estimativa de resultados</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Footer -->
        <footer class="bg-gray-900 text-white py-12">
            <div class="container mx-auto px-6">
                <div class="text-center">
                    <div class="flex items-center justify-center space-x-2 mb-6">
                        <i class="fas fa-map-marker-alt text-2xl bg-gradient-to-r from-emerald-400 to-green-500 bg-clip-text text-transparent"></i>
                        <span class="text-xl font-bold">Perfil de Empresa Fortaleza</span>
                    </div>
                    <p class="text-gray-400 mb-6">
                        Especialistas em Google Perfil da Empresa - Marketing Digital em Fortaleza
                    </p>
                    <div class="flex justify-center space-x-6 mb-8">
                        <a href="#" class="text-gray-400 hover:text-blue-400 transition">
                            <i class="fab fa-facebook text-2xl"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-blue-400 transition">
                            <i class="fab fa-instagram text-2xl"></i>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-blue-400 transition">
                            <i class="fab fa-linkedin text-2xl"></i>
                        </a>
                    </div>
                    <p class="text-gray-500 text-sm">
                        © 2024 Perfil de Empresa Fortaleza. Todos os direitos reservados.
                    </p>
                </div>
            </div>
        </footer>

        <!-- WhatsApp Float Button -->
        <a href="https://wa.me/5585996720379?text=Ola! Gostaria de saber mais sobre os servicos de Google Perfil da Empresa." 
           target="_blank" 
           class="whatsapp-float bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-2xl transition-all duration-300 transform hover:scale-110">
            <i class="fab fa-whatsapp text-2xl"></i>
        </a>

        <!-- Payment Modal -->
        <div id="payment-modal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden">
            <div class="flex items-center justify-center min-h-screen p-4">
                <div class="bg-white rounded-2xl p-8 max-w-md w-full relative">
                    <button onclick="closePaymentModal()" class="absolute top-4 right-4 text-gray-500 hover:text-gray-700">
                        <i class="fas fa-times text-xl"></i>
                    </button>
                    
                    <div class="text-center">
                        <h3 class="text-2xl font-bold mb-4" id="modal-plan-title">Plano Selecionado</h3>
                        <div class="text-3xl font-bold text-blue-600 mb-6" id="modal-price">R$ 499/mês</div>
                        
                        <div class="space-y-4">
                            <button onclick="redirectToPayment()" class="w-full bg-gradient-to-r from-green-500 to-green-600 text-white py-4 rounded-xl font-semibold text-lg hover:shadow-lg transition-all duration-300">
                                <i class="fas fa-shopping-cart mr-2"></i>
                                Finalizar Assinatura
                            </button>
                        </div>
                        
                        <p class="text-sm text-gray-600 mt-4">
                            Escolha cartão ou boleto na próxima página
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <script src="https://cdn.jsdelivr.net/npm/axios@1.6.0/dist/axios.min.js"></script>
        <script>
            // Mobile menu toggle
            document.getElementById('mobile-menu-btn').addEventListener('click', function() {
                const menu = document.getElementById('mobile-menu');
                menu.classList.toggle('hidden');
            });

            // Smooth scrolling for navigation links
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();
                    const target = document.querySelector(this.getAttribute('href'));
                    if (target) {
                        target.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                });
            });

            // Contact form submission
            document.getElementById('contact-form').addEventListener('submit', async function(e) {
                e.preventDefault();
                
                const formData = new FormData(e.target);
                const data = {
                    name: formData.get('name'),
                    email: formData.get('email'),
                    phone: formData.get('phone'),
                    service: formData.get('service')
                };
                
                try {
                    const response = await axios.post('/api/contact', data);
                    if (response.data.success) {
                        alert('Mensagem enviada com sucesso! Entraremos em contato em breve.');
                        e.target.reset();
                    }
                } catch (error) {
                    alert('Erro ao enviar mensagem. Tente novamente ou entre em contato via WhatsApp.');
                }
            });

            // Payment modal functions
            let selectedPlan = '';
            
            function openPaymentModal(plan) {
                selectedPlan = plan;
                const modal = document.getElementById('payment-modal');
                const titleElement = document.getElementById('modal-plan-title');
                const priceElement = document.getElementById('modal-price');
                
                if (plan === 'anual') {
                    titleElement.textContent = 'Plano Anual';
                    priceElement.textContent = 'R$ 499/mês';
                } else {
                    titleElement.textContent = 'Plano Semestral';
                    priceElement.textContent = 'R$ 699/mês';
                }
                
                modal.classList.remove('hidden');
            }
            
            function closePaymentModal() {
                const modal = document.getElementById('payment-modal');
                modal.classList.add('hidden');
            }
            
            function redirectToPayment() {
                // Integração com o gateway Asaas
                let paymentUrl = '';
                
                if (selectedPlan === 'anual') {
                    paymentUrl = 'https://www.asaas.com/c/i133mmhnwvmbx36b';
                } else {
                    paymentUrl = 'https://www.asaas.com/c/1mkk5l1e5h12ml8n';
                }
                
                window.open(paymentUrl, '_blank');
                closePaymentModal();
            }

            // Close modal when clicking outside
            document.getElementById('payment-modal').addEventListener('click', function(e) {
                if (e.target === this) {
                    closePaymentModal();
                }
            });
        </script>
    </body>
    </html>
  `)
})

export default app
