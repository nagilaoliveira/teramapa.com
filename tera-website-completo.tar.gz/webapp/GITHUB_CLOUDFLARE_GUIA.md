# 🚀 Guia Simples: Como Conectar Cloudflare com GitHub (Para Iniciantes)

## 🎯 O que você vai conseguir fazer:
- Toda vez que você fizer uma alteração no código no GitHub, seu site será atualizado automaticamente
- Não precisa fazer upload manual de arquivos
- Deploy automático e profissional

---

## 📋 Você vai precisar de:
1. ✅ **Conta GitHub** (gratuita) - onde fica o código
2. ✅ **Conta Cloudflare** (gratuita) - onde fica o site
3. ✅ **Domínio tera.com** já configurado no Cloudflare

---

## 🔗 PASSO A PASSO SIMPLES

### **PARTE 1: Colocar o Código no GitHub**

#### **1.1 Criar Repositório no GitHub**
```
1. Entre no GitHub.com
2. Clique no botão verde "New" (Novo)
3. Nome do repositório: "tera-website" 
4. Deixe "Public" selecionado
5. Clique "Create repository"
```

#### **1.2 Fazer Upload dos Arquivos**
```
1. No repositório criado, clique "uploading an existing file"
2. Arraste TODOS os arquivos da pasta do seu site
3. Escreva "Primeiro upload do site" na caixa de commit
4. Clique "Commit changes"
```

### **PARTE 2: Conectar Cloudflare ao GitHub**

#### **2.1 Ir para Cloudflare Pages**
```
1. Entre no Cloudflare.com
2. No menu lateral, clique "Pages"  
3. Clique "Create a project"
4. Escolha "Connect to Git"
```

#### **2.2 Conectar com GitHub**
```
1. Clique "Connect GitHub"
2. Uma janela vai abrir pedindo permissão
3. Clique "Authorize Cloudflare"
4. Escolha seu repositório "tera-website"
5. Clique "Begin setup"
```

#### **2.3 Configurar o Build**
```
Na tela de configuração, preencha:

📋 Project name: tera-website
📋 Production branch: main  
📋 Framework preset: None (deixe em branco)
📋 Build command: npm run build
📋 Build output directory: dist
📋 Root directory: / (deixe em branco)

Depois clique "Save and Deploy"
```

### **PARTE 3: Configurar o Domínio tera.com**

#### **3.1 Adicionar Domínio Personalizado**
```
1. Após o deploy (uns 2-3 minutos), clique no projeto
2. Vá na aba "Custom domains"
3. Clique "Set up a custom domain"
4. Digite: tera.com
5. Clique "Continue"
6. Clique "Activate domain"
```

---

## ✅ PRONTO! COMO FUNCIONA AGORA:

### **🔄 Deploy Automático:**
```
1. Você altera algo no código
2. Faz upload no GitHub (ou usa o editor web)
3. Em 1-2 minutos, o site tera.com já está atualizado!
```

### **📱 Como Fazer Alterações:**
```
OPÇÃO FÁCIL (pelo navegador):
1. Entre no GitHub.com
2. Abra seu repositório "tera-website"  
3. Clique no arquivo que quer editar
4. Clique no lápis (Edit)
5. Faça as mudanças
6. Clique "Commit changes"
7. Aguarde 1-2 minutos = site atualizado!
```

---

## 🎨 EXEMPLO PRÁTICO: Mudar Telefone WhatsApp

### **Como alterar o número do WhatsApp:**
```
1. No GitHub, abra o arquivo "src/index.tsx"
2. Procure por "5585996720379"  
3. Troque pelo novo número (só os números)
4. Clique "Commit changes"
5. Pronto! Em 2 minutos o site tem o novo número
```

---

## 🆘 SE DER PROBLEMA:

### **❌ "Build Failed" (Falha no Build):**
```
1. Vá em Pages → seu projeto → Deployments
2. Clique no deploy que falhou
3. Veja o log de erro
4. Geralmente é arquivo faltando ou erro de sintaxe
```

### **❌ Site não carrega:**
```
1. Aguarde até 10 minutos (propagação DNS)
2. Teste https://tera.com em navegador anônimo
3. Se ainda não funcionar, verifique se o domínio 
   está mesmo configurado no Cloudflare
```

### **❌ Alterações não aparecem:**
```
1. Confirme que o commit foi feito no GitHub
2. Vá em Pages → Deployments
3. Veja se o novo deploy está "Success" 
4. Limpe cache do navegador (Ctrl+F5)
```

---

## 🎯 VANTAGENS DESTA CONFIGURAÇÃO:

### **✅ Para Você:**
- ✨ **Fácil**: Edita pelo navegador, sem programas
- 🚀 **Rápido**: Mudanças aparecem em 1-2 minutos  
- 🔒 **Seguro**: Backup automático no GitHub
- 💰 **Gratuito**: GitHub e Cloudflare são grátis
- 📱 **Mobile**: Pode editar pelo celular

### **✅ Para Seu Site:**
- ⚡ **Rápido**: CDN global do Cloudflare
- 🔐 **Seguro**: SSL automático
- 🌍 **Confiável**: 99.9% uptime
- 📈 **Escalável**: Suporta milhões de visitas

---

## 📞 RESUMO DE 30 SEGUNDOS:

```
1. GitHub.com → New repository → Upload arquivos
2. Cloudflare.com → Pages → Connect Git → Escolha repositório  
3. Configure: build=npm run build, output=dist
4. Adicione domínio tera.com
5. Pronto! Edite no GitHub = site atualiza sozinho
```

**🎉 Resultado: Site profissional com deploy automático em https://tera.com!**

---

## 🔗 LINKS ÚTEIS:
- **GitHub**: https://github.com
- **Cloudflare**: https://cloudflare.com  
- **Seu site**: https://tera.com (após configuração)
- **Suporte Cloudflare**: https://community.cloudflare.com