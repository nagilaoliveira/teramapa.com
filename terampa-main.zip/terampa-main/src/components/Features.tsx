import React from 'react';
import { motion } from 'motion/react';
import { Target, Zap, Clock, Medal } from 'lucide-react';

const features = [
  {
    icon: Target,
    title: 'Especialização Exclusiva',
    description: 'Focamos 100% no Google Perfil da Empresa (SEO Local). Fazemos uma única coisa e fazemos melhor que ninguém.',
  },
  {
    icon: Medal,
    title: 'Resultados Comprovados',
    description: 'Nossa metodologia já posicionou dezenas de empresas no topo das buscas do Google Maps em suas regiões.',
  },
  {
    icon: Clock,
    title: 'Agilidade Garantida',
    description: 'Processos estruturados para criar, otimizar ou iniciar a recuperação do seu perfil em tempo recorde.',
  },
  {
    icon: Zap,
    title: 'Mais Clientes Reais',
    description: 'Transformamos visualizações em ações: mais rotas traçadas, mais chamadas e mais vendas para o seu negócio.',
  }
];

export default function Features() {
  return (
    <section id="vantagens" className="py-24 bg-[#0a0a1a] border-b border-cyan-900/30 relative">
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-5"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 drop-shadow-sm">
            Por que escolher a <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500 drop-shadow-[0_0_15px_rgba(6,182,212,0.4)]">TeraMapa</span>?
          </h2>
          <p className="text-lg text-slate-300">
            Não somos uma agência genérica. Somos especialistas no que traz resultado imediato para o varejo e serviços locais.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="bg-slate-900/50 backdrop-blur-md rounded-2xl p-8 hover:bg-slate-800 hover:shadow-[0_0_25px_rgba(6,182,212,0.3)] hover:-translate-y-1 transition-all duration-300 border border-slate-800 hover:border-cyan-500/50 group"
              >
                <div className="w-12 h-12 bg-cyan-950/50 text-cyan-400 border border-cyan-800/50 rounded-xl flex items-center justify-center mb-6 shadow-[0_0_15px_rgba(6,182,212,0.2)] group-hover:shadow-[0_0_20px_rgba(6,182,212,0.5)] transition-all">
                  <Icon size={24} />
                </div>
                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-cyan-300 transition-colors">{feature.title}</h3>
                <p className="text-slate-400 leading-relaxed group-hover:text-slate-300 transition-colors">
                  {feature.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
