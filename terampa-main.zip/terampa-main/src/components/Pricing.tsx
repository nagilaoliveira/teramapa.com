import React from 'react';
import { motion } from 'motion/react';
import { CheckCircle2 } from 'lucide-react';

const plans = [
  {
    name: 'Setup / Recuperação',
    description: 'Para empresas precisando criar um perfil do zero ou recuperar conta suspensa.',
    durationLabel: 'Formato',
    duration: 'Único',
    popular: false,
    features: [
      'Criação de Perfil do Zero',
      'Recuperação de Contas Suspensas',
      'Configuração Inicial Completa',
      'Ajuste de Categoria e Informações',
      'Verificação de Ficha',
      'Suporte via WhatsApp'
    ]
  },
  {
    name: 'Plano Semestral',
    description: 'Ideal para quem busca tracionar os resultados locais em médio prazo.',
    durationLabel: 'Contrato de',
    duration: '6 meses',
    popular: false,
    features: [
      'Otimização Completa Inicial',
      'Ajuste de Categoria e Palavras-chave',
      'Inclusão de Produtos/Serviços',
      'Resposta de Avaliações (Mensal)',
      'Relatório de Desempenho (Mensal)',
      'Suporte via WhatsApp'
    ]
  },
  {
    name: 'Plano Anual',
    description: 'A solução definitiva para dominar sua região e manter a liderança.',
    durationLabel: 'Contrato de',
    duration: '12 meses',
    popular: true,
    features: [
      'Tudo do Plano Semestral',
      'Monitoramento de Concorrência Local',
      'Estratégia de Postagens Frequentes',
      'Treinamento para Coleta de Avaliações',
      'Recuperação Prioritária (em caso de suspensão)',
      'Relatório Estratégico Detalhado',
      'Suporte Prioritário VIP'
    ]
  }
];

export default function Pricing() {
  return (
    <section id="planos" className="py-24 bg-[#0a0a1a] relative">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-cyan-900/10 rounded-full blur-[120px] -z-10"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Investimento com Retorno
          </h2>
          <p className="text-lg text-slate-400">
            Escolha o plano ideal para acelerar e manter o posicionamento da sua empresa.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.2 }}
              className={`relative backdrop-blur-xl rounded-3xl p-8 md:p-10 border transition-all duration-300 ${
                plan.popular 
                  ? 'bg-cyan-950/20 border-cyan-400/40 shadow-[0_8px_32px_rgba(6,182,212,0.2)]' 
                  : 'bg-white/[0.03] border-white/10 shadow-[0_8px_32px_rgba(0,0,0,0.5)]'
              }`}
            >
              {plan.popular && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-gradient-to-r from-cyan-500 to-purple-600 text-white px-4 py-1.5 rounded-full text-sm font-bold tracking-wide uppercase shadow-[0_0_15px_rgba(6,182,212,0.5)]">
                  Mais Escolhido
                </div>
              )}
              
              <h3 className="text-2xl font-bold text-white mb-2">{plan.name}</h3>
              <p className="text-slate-400 mb-6 min-h-[48px]">{plan.description}</p>
              
              <div className="mb-8 pb-8 border-b border-slate-800">
                <span className="text-sm font-medium text-slate-500 uppercase tracking-wider block mb-1">
                  {plan.durationLabel}
                </span>
                <span className="text-4xl font-extrabold text-white">{plan.duration}</span>
              </div>

              <ul className="space-y-4 mb-10">
                {plan.features.map((feature, fIndex) => (
                  <li key={fIndex} className="flex items-start gap-3">
                    <CheckCircle2 size={20} className="text-cyan-400 shrink-0 mt-0.5" />
                    <span className="text-slate-300">{feature}</span>
                  </li>
                ))}
              </ul>

              <a
                href={`https://wa.me/5585991840829?text=${encodeURIComponent(`Olá, tenho interesse no ${plan.name} da TeraMapa.`)}`}
                target="_blank"
                rel="noopener noreferrer"
                className={`w-full block text-center py-4 rounded-xl font-bold transition-all ${
                  plan.popular
                    ? 'bg-gradient-to-r from-cyan-600 to-blue-600 text-white hover:shadow-[0_0_20px_rgba(6,182,212,0.5)]'
                    : 'bg-slate-800 text-white hover:bg-slate-700 border border-slate-700'
                }`}
              >
                Falar com Consultor
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
