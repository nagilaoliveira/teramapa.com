import React from 'react';
import { motion } from 'motion/react';
import { Award, ShieldCheck, CheckCircle, TrendingUp } from 'lucide-react';

export default function TrustBadges() {
  const badges = [
    {
      icon: Award,
      title: "Google Partner",
      subtitle: "Certificação Oficial"
    },
    {
      icon: ShieldCheck,
      title: "Especialista SEO",
      subtitle: "Local & Orgânico"
    },
    {
      icon: CheckCircle,
      title: "Agência Verificada",
      subtitle: "Resultados Comprovados"
    },
    {
      icon: TrendingUp,
      title: "Alta Performance",
      subtitle: "Foco em Conversão"
    }
  ];

  return (
    <section className="py-12 bg-[#05050f] border-b border-cyan-900/30 relative overflow-hidden">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full bg-cyan-900/5 blur-[100px] -z-10"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <p className="text-center text-xs font-semibold text-slate-400 uppercase tracking-widest mb-8">
          Certificações e Reconhecimentos
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 text-center">
          {badges.map((badge, index) => {
            const Icon = badge.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="flex flex-col items-center justify-center p-6 rounded-2xl bg-white/[0.02] border border-white/5 hover:border-cyan-500/30 hover:bg-white/[0.05] hover:shadow-[0_0_20px_rgba(6,182,212,0.1)] transition-all group"
              >
                <div className="w-14 h-14 bg-gradient-to-br from-cyan-900/40 to-purple-900/40 border border-cyan-800/30 rounded-full flex items-center justify-center mb-4 text-cyan-400 group-hover:scale-110 group-hover:text-cyan-300 transition-all shadow-[0_0_10px_rgba(6,182,212,0.2)]">
                  <Icon size={26} />
                </div>
                <h4 className="font-bold text-white text-sm md:text-base drop-shadow-sm">{badge.title}</h4>
                <p className="text-xs text-slate-400 mt-1.5">{badge.subtitle}</p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
