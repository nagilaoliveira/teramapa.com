import React from 'react';
import { MapPin, Instagram, Mail, Phone } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-[#05050f] text-slate-400 py-12 border-t border-cyan-900/30 relative overflow-hidden">
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-cyan-900/10 blur-[100px] rounded-t-full -z-10"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 md:gap-8">
          
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-6">
              <img 
                src="/logo.webp" 
                alt="TeraMapa Logo" 
                className="h-16 w-auto object-contain"
                onError={(e) => {
                  const target = e.currentTarget as HTMLImageElement;
                  target.style.display = 'none';
                  const fallback = target.nextElementSibling as HTMLElement;
                  if (fallback) fallback.style.display = 'flex';
                }}
              />
              <div className="hidden items-center gap-2" style={{ display: 'none' }}>
                <div className="w-8 h-8 bg-gradient-to-tr from-cyan-500 to-purple-600 rounded flex items-center justify-center shadow-[0_0_15px_rgba(6,182,212,0.5)]">
                  <div className="w-4 h-4 border-2 border-white rounded-full"></div>
                </div>
                <span className="text-xl font-bold tracking-tight text-white">TERA<span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500">MAPA</span></span>
              </div>
            </div>
            <p className="text-slate-400 mb-6 max-w-sm leading-relaxed">
              Especialistas em Google Perfil da Empresa, SEO Local e posicionamento orgânico para negócios locais no Brasil.
            </p>
            <div className="flex items-center gap-4">
              <a href="#" className="w-10 h-10 bg-slate-900 rounded-full flex items-center justify-center hover:bg-cyan-600 hover:text-white hover:shadow-[0_0_15px_rgba(6,182,212,0.5)] transition-all">
                <Instagram size={20} />
              </a>
              <a href="#" className="w-10 h-10 bg-slate-900 rounded-full flex items-center justify-center hover:bg-cyan-600 hover:text-white hover:shadow-[0_0_15px_rgba(6,182,212,0.5)] transition-all">
                <Mail size={20} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4 uppercase tracking-wider text-sm drop-shadow-sm">Serviços</h4>
            <ul className="space-y-3">
              <li><a href="#servicos" className="hover:text-cyan-400 transition-colors">Recuperação de Perfil</a></li>
              <li><a href="#servicos" className="hover:text-cyan-400 transition-colors">Criação de Perfil</a></li>
              <li><a href="#servicos" className="hover:text-cyan-400 transition-colors">SEO Local</a></li>
              <li><a href="#servicos" className="hover:text-cyan-400 transition-colors">Gerenciamento</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-4 uppercase tracking-wider text-sm drop-shadow-sm">Contato</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-slate-400">
                <Phone size={16} />
                <span>(85) 99184-0829</span>
              </li>
              <li className="flex items-center gap-2 text-slate-400">
                <Mail size={16} />
                <span>contato@teramapa.com</span>
              </li>
              <li className="flex items-center gap-2 text-slate-400 mt-4">
                <MapPin size={16} className="shrink-0" />
                <span>Brasil</span>
              </li>
            </ul>
          </div>

        </div>
        
        <div className="mt-12 pt-8 border-t border-cyan-900/30 text-center md:text-left flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-slate-500">
          <p>© {new Date().getFullYear()} TeraMapa. Todos os direitos reservados.</p>
          <div className="flex gap-4">
            <a href="#" className="hover:text-white transition-colors">Termos de Uso</a>
            <a href="#" className="hover:text-white transition-colors">Política de Privacidade</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
