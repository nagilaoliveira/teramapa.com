import React from 'react';
import { motion } from 'motion/react';
import { Star } from 'lucide-react';

const testimonials = [
  {
    name: 'Carlos Oliveira',
    business: 'Clínica Odontológica no Brasil',
    content: 'Tivemos nosso perfil suspenso do nada e perdemos 40% das ligações. A equipe da TeraMapa recuperou em poucos dias e ainda otimizou. Voltamos ao topo!',
    rating: 5,
  },
  {
    name: 'Mariana Silva',
    business: 'Escritório de Advocacia',
    content: 'O trabalho de SEO Local mudou nosso jogo. Antes não aparecíamos no mapa, hoje recebemos contatos de clientes qualificados todos os dias pela ficha do Google.',
    rating: 5,
  },
  {
    name: 'Roberto Mendes',
    business: 'Oficina Mecânica',
    content: 'Eles assumiram toda a gestão do nosso Google Meu Negócio. As postagens, respostas e otimizações fizeram nosso fluxo de clientes dobrar no último semestre.',
    rating: 5,
  }
];

export default function Testimonials() {
  return (
    <section id="depoimentos" className="py-24 bg-gradient-to-b from-[#05050f] to-[#0a0a1a] text-white overflow-hidden relative">
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-purple-900/20 rounded-full blur-[100px] -z-10"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center max-w-3xl mx-auto mb-16"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4 drop-shadow-[0_0_15px_rgba(255,255,255,0.2)]">
            Resultados Comprovados no Brasil
          </h2>
          <p className="text-cyan-200/80 text-lg">
            Veja o que empresários locais dizem sobre o nosso trabalho de posicionamento.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {testimonials.map((t, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-slate-900/40 p-8 rounded-2xl border border-cyan-900/40 backdrop-blur-md shadow-[0_0_20px_rgba(0,0,0,0.5)] hover:border-cyan-500/50 hover:shadow-[0_0_25px_rgba(6,182,212,0.15)] transition-all"
            >
              <div className="flex gap-1 mb-6">
                {[...Array(t.rating)].map((_, i) => (
                  <Star key={i} size={18} className="fill-amber-400 text-amber-400 drop-shadow-[0_0_8px_rgba(251,191,36,0.5)]" />
                ))}
              </div>
              <p className="text-slate-300 text-lg leading-relaxed mb-6 italic">
                "{t.content}"
              </p>
              <div>
                <p className="font-bold text-white drop-shadow-sm">{t.name}</p>
                <p className="text-cyan-400 text-sm">{t.business}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
