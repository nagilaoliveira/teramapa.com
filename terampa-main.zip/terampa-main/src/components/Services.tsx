import React from 'react';
import { motion } from 'motion/react';
import { ShieldAlert, Store, MapPin, BarChart3, Settings2, Users2 } from 'lucide-react';

const services = [
  {
    icon: ShieldAlert,
    title: 'Recuperação de Perfil',
    description: 'Teve sua conta suspensa pelo Google? Nossa equipe atua rapidamente para contatar o suporte, resolver as infrações e devolver sua visibilidade.',
    color: 'text-red-400',
    bgColor: 'bg-red-950/30 border border-red-800/50 shadow-[0_0_15px_rgba(248,113,113,0.1)]',
  },
  {
    icon: Store,
    title: 'Criação de Perfil',
    description: 'Criamos o perfil da sua empresa do zero, seguindo todas as diretrizes do Google para garantir aprovação rápida e destaque na pesquisa.',
    color: 'text-teal-400',
    bgColor: 'bg-teal-950/30 border border-teal-800/50 shadow-[0_0_15px_rgba(45,212,191,0.1)]',
  },
  {
    icon: MapPin,
    title: 'SEO Local',
    description: 'Otimização avançada de palavras-chave locais, categorias e descrições para que sua empresa apareça no cobiçado "Local Pack" (3 primeiros).',
    color: 'text-emerald-400',
    bgColor: 'bg-emerald-950/30 border border-emerald-800/50 shadow-[0_0_15px_rgba(52,211,153,0.1)]',
  },
  {
    icon: BarChart3,
    title: 'Posicionamento e Rankeamento',
    description: 'Estratégias contínuas para manter sua empresa à frente da concorrência local, expandindo seu raio de atuação e alcance na cidade.',
    color: 'text-purple-400',
    bgColor: 'bg-purple-950/30 border border-purple-800/50 shadow-[0_0_15px_rgba(192,132,252,0.1)]',
  },
  {
    icon: Settings2,
    title: 'Gerenciamento Completo',
    description: 'Cuidamos de tudo: atualizações, postagens de fotos, respostas a clientes e monitoramento constante para que você foque apenas em vender.',
    color: 'text-amber-400',
    bgColor: 'bg-amber-950/30 border border-amber-800/50 shadow-[0_0_15px_rgba(251,191,36,0.1)]',
  },
  {
    icon: Users2,
    title: 'Consultoria Especializada',
    description: 'Sessões de consultoria para treinar sua equipe a solicitar avaliações e compreender as métricas do painel do Google Meu Negócio.',
    color: 'text-cyan-400',
    bgColor: 'bg-cyan-950/30 border border-cyan-800/50 shadow-[0_0_15px_rgba(34,211,238,0.1)]',
  }
];

export default function Services() {
  return (
    <section id="servicos" className="py-24 bg-[#05050f] relative overflow-hidden">
      <div className="absolute top-1/4 -left-32 w-[500px] h-[500px] bg-purple-900/20 rounded-full blur-[120px] -z-10"></div>
      <div className="absolute bottom-1/4 -right-32 w-[500px] h-[500px] bg-cyan-900/20 rounded-full blur-[120px] -z-10"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Nossas Soluções
            </h2>
            <p className="text-lg text-slate-400">
              Serviços desenhados para extrair o máximo potencial da sua presença digital local.
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="relative overflow-hidden bg-white/[0.03] backdrop-blur-md p-8 rounded-3xl shadow-[0_8px_32px_rgba(0,0,0,0.5)] border border-white/10 hover:border-cyan-400/30 hover:bg-white/[0.06] hover:shadow-[0_8px_32px_rgba(6,182,212,0.2)] hover:-translate-y-2 transition-all duration-300 group"
              >
                <div className="absolute -top-24 -right-24 w-48 h-48 bg-cyan-500/10 rounded-full blur-2xl group-hover:bg-cyan-500/20 transition-all duration-500 -z-10"></div>
                <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 ${service.bgColor} ${service.color} group-hover:scale-110 transition-transform relative z-10`}>
                  <Icon size={28} />
                </div>
                <h3 className="text-xl font-bold text-white mb-3">{service.title}</h3>
                <p className="text-slate-400 leading-relaxed group-hover:text-slate-300 transition-colors">
                  {service.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
