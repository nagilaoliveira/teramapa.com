import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight, Star, ShieldCheck, TrendingUp } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative pt-32 pb-20 lg:pt-48 lg:pb-32 overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-cyan-900/40 via-[#0a0a1a] to-[#0a0a1a]"></div>
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-600/20 rounded-full blur-[100px] -z-10"></div>
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-600/20 rounded-full blur-[100px] -z-10"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-cyan-950/50 border border-cyan-800/50 text-cyan-400 text-sm font-medium mb-6 shadow-[0_0_15px_rgba(6,182,212,0.2)] backdrop-blur-sm"
          >
            <Star size={14} className="fill-cyan-400" />
            <span>Especialistas em SEO Local no Brasil</span>
          </motion.div>
          
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tight text-white mb-6 leading-tight drop-shadow-sm"
          >
            Domine o <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-500 drop-shadow-[0_0_15px_rgba(6,182,212,0.4)]">Google Meu Negócio</span> e multiplique vendas
          </motion.h1>
          
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
            className="text-lg md:text-xl text-slate-300 mb-10 max-w-2xl mx-auto"
          >
            Ajudamos empresas locais a conquistarem o topo das buscas, recuperarem contas suspensas e atraírem clientes qualificados todos os dias.
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <a
              href="#contato"
              className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-cyan-600 to-blue-600 text-white text-lg font-semibold rounded-xl hover:shadow-[0_0_25px_rgba(6,182,212,0.6)] hover:scale-105 transition-all active:scale-95 flex items-center justify-center gap-2 border border-cyan-400/30"
            >
              Fazer Análise Gratuita
              <ArrowRight size={20} />
            </a>
            <a
              href="#servicos"
              className="w-full sm:w-auto px-8 py-4 bg-slate-900/50 backdrop-blur-md text-slate-200 text-lg font-semibold rounded-xl hover:bg-slate-800 hover:text-white shadow-[0_0_15px_rgba(0,0,0,0.5)] border border-slate-700 hover:border-cyan-500/50 transition-all active:scale-95"
            >
              Conhecer Serviços
            </a>
          </motion.div>
        </div>

        {/* Trust Indicators */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.6 }}
          className="mt-20 pt-10 border-t border-slate-800/50"
        >
          <p className="text-center text-sm font-medium text-slate-400 mb-6 uppercase tracking-wider">
            Resultados que entregamos
          </p>
          <div className="flex flex-wrap justify-center gap-8 md:gap-16">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-purple-950/50 border border-purple-800/50 rounded-lg text-purple-400 shadow-[0_0_10px_rgba(168,85,247,0.3)]">
                <TrendingUp size={24} />
              </div>
              <div className="text-left">
                <p className="text-2xl font-bold text-white">+300%</p>
                <p className="text-xs text-slate-400 font-medium">Mais ligações</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-cyan-950/50 border border-cyan-800/50 rounded-lg text-cyan-400 shadow-[0_0_10px_rgba(6,182,212,0.3)]">
                <ShieldCheck size={24} />
              </div>
              <div className="text-left">
                <p className="text-2xl font-bold text-white">100%</p>
                <p className="text-xs text-slate-400 font-medium">Contas recuperadas</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <div className="p-2 bg-amber-950/50 border border-amber-800/50 rounded-lg text-amber-400 shadow-[0_0_10px_rgba(245,158,11,0.3)]">
                <Star size={24} className="fill-amber-400" />
              </div>
              <div className="text-left">
                <p className="text-2xl font-bold text-white">4.9/5</p>
                <p className="text-xs text-slate-400 font-medium">Média de avaliações</p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
