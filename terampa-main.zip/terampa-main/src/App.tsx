/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import TrustBadges from './components/TrustBadges';
import Services from './components/Services';
import Features from './components/Features';
import Pricing from './components/Pricing';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';
import Footer from './components/Footer';
import FloatingChat from './components/FloatingChat';

export default function App() {
  return (
    <div className="min-h-screen bg-[#0a0a1a] text-slate-200 font-sans selection:bg-cyan-500 selection:text-white">
      <Header />
      <main>
        <Hero />
        <TrustBadges />
        <Features />
        <Services />
        <Testimonials />
        <Pricing />
        <Contact />
      </main>
      <Footer />
      <FloatingChat />
    </div>
  );
}
